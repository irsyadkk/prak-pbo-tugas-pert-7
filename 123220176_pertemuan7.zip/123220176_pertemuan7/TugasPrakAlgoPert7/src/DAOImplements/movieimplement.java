/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAOImplements;
import java.util.List;
import model.*;

/**
 *
 * @author Irsyad
 */
public interface movieimplement {
    public void insert(movie m);
    public void update(movie m);
    public void delete(String judul);
    public List<movie> getAll();
    public void truncate();
    
    
}
