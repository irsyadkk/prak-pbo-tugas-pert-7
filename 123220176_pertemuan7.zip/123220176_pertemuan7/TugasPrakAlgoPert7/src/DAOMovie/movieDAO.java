/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAOMovie;
import java.sql.*;
import java.util.*;
import connection.*;
import model.*;
import DAOImplements.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import view.*;

/**
 *
 * @author Irsyad
 */
public class movieDAO implements movieimplement{
    Connection connection;
    UI frame;
    final String select = "Select * From movie";
    final String insert = "INSERT INTO movie (judul, alur, penokohan, akting, nilai) VALUES ( ?, ?, ?, ?, ?);";
    final String update = "update movie set judul=?, alur=?, penokohan=?, akting=?, nilai=? where judul=?";
    final String delete = "delete from movie where judul=?";
    final String truncate = "truncate table movie";
    
    public movieDAO(){
        connection = connector.connect();
    }

    @Override
    public void insert(movie m) {
        PreparedStatement statement = null;
        try{
            statement = connection.prepareStatement(insert,Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, m.getJudul());
            statement.setDouble(2, m.getAlur());
            statement.setDouble(3, m.getPenokohan());
            statement.setDouble(4, m.getAkting());
            statement.setDouble(5, (m.getAlur()+m.getPenokohan()+m.getAkting())/3);
            statement.executeUpdate();
            ResultSet rs = statement.getGeneratedKeys();
        }catch(SQLException e){
            e.printStackTrace();
        }finally{
        try{
            statement.close();
        }catch(SQLException e){
            e.printStackTrace();
        }
    }
    }

    @Override
    public void update(movie m) {
        PreparedStatement statement = null;
        try{
            statement = connection.prepareStatement(update);
            if(m.getJudul()==m.getJudulLama()){
            statement.setDouble(2, m.getAlur());
            statement.setDouble(3, m.getPenokohan());
            statement.setDouble(4, m.getAkting());
            statement.setDouble(5, (m.getAlur()+m.getPenokohan()+m.getAkting())/3);
            statement.setString(6, m.getJudulLama());
            }
            else{
            statement.setString(1, m.getJudul());
            statement.setDouble(2, m.getAlur());
            statement.setDouble(3, m.getPenokohan());
            statement.setDouble(4, m.getAkting());
            statement.setDouble(5, (m.getAlur()+m.getPenokohan()+m.getAkting())/3);
            statement.setString(6, m.getJudulLama());
            }
            statement.executeUpdate();    
        }catch(SQLException e){
            e.printStackTrace();
        }finally{
        try{
            statement.close();
        }catch(SQLException e){
            e.printStackTrace();
        }
    }
    }

    @Override
    public void delete(String judul) {
        PreparedStatement statement = null;
        try{
            statement = connection.prepareStatement(delete);
            statement.setString(1, judul);
            statement.executeUpdate();
        }catch(SQLException e){
            e.printStackTrace();
        }finally{
        try{
            statement.close();
        }catch(SQLException e){
            e.printStackTrace();
        }
    }
    }
    
    @Override
    public void truncate(){
        PreparedStatement statement = null;
        try{
            statement = connection.prepareStatement(truncate);
            statement.executeUpdate();
        }catch(SQLException e){
            e.printStackTrace();
        }finally{
        try{
            statement.close();
        }catch(SQLException e){
            e.printStackTrace();
        }
        
    }
    }

    @Override
    public List<movie> getAll() {
        List<movie> dm = null;
        try{
            dm = new ArrayList<movie>();
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(select);
            while (rs.next())
            {
                movie movie = new movie();  
                movie.setJudul(rs.getString("judul"));
                movie.setAlur(rs.getDouble("alur"));
                movie.setPenokohan(rs.getDouble("penokohan"));
                movie.setAkting(rs.getDouble("akting"));
                movie.setNilai(rs.getDouble("nilai"));
                dm.add(movie);
                
            }
        }catch(SQLException e){
            Logger.getLogger(movieDAO.class.getName()).log(Level.SEVERE,null,e);
        }
        return dm;
    }
}
