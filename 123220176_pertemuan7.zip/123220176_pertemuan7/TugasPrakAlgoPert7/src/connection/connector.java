/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connection;
import com.mysql.cj.jdbc.MysqlDataSource;
import java.sql.*;

/**
 *
 * @author Irsyad
 */
public class connector {
    static Connection con;
    
    public static Connection connect(){
        if (con==null)
        {
            MysqlDataSource data = new MysqlDataSource();
            data.setDatabaseName("movie_db");
            data.setUser("root");
            data.setPassword("");
            try{
                con = data.getConnection();
                System.out.println("Connected");
            }catch(SQLException e){
                e.printStackTrace();
                System.out.println("Connection Error");
            }
        }
        return con;
    }
    
}
