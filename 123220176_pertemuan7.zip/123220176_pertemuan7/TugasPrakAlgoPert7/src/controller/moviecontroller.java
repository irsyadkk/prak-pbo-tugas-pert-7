/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
import java.util.List;
import DAOMovie.*;
import DAOImplements.*;
import model.*;
import view.*;
import com.mysql.cj.jdbc.MysqlDataSource;
import java.sql.*;
import java.util.InputMismatchException;
import javax.swing.*;

/**
 *
 * @author Irsyad
 */
public class moviecontroller {
    UI frame;
    movieimplement impmovie;
    List<movie> dm;
    Double alur,penokohan,akting,nilai;
    
    public moviecontroller(UI frame){
        this.frame = frame;
        impmovie = new movieDAO();
        dm = impmovie.getAll();
    }
    
    public void tablecontent(){
        dm = impmovie.getAll();
        modeltable model = new modeltable(dm);
        frame.getMovieDataTable().setModel(model);
    }
    
    public void insert(){
        try {
        movie dm = new movie();
        dm.setJudul(frame.getJTextJudul().getText());
        dm.setAlur(Double.parseDouble(frame.getJTextAlur().getText()));
        alur= dm.getAlur();
        dm.setPenokohan(Double.parseDouble(frame.getJTextPenokohan().getText()));
        penokohan = dm.getPenokohan();
        dm.setAkting(Double.parseDouble(frame.getJTextAkting().getText()));
        akting = dm.getAkting();
        nilai = (alur+penokohan+akting)/3;
        dm.setNilai(nilai);
        if(0<alur && alur<=5 && 0<akting && akting<=5 && 0<penokohan && penokohan<=5){
        impmovie.insert(dm);
        JOptionPane.showMessageDialog(frame,"Data Movie Berhasil Ditambahkan !","Success",JOptionPane.INFORMATION_MESSAGE);
        }
        else{
            JOptionPane.showMessageDialog(frame, "Mohon Masukan Input Yang Sesuai Dengan Range 0,1 - 5 !","Invalid",JOptionPane.ERROR_MESSAGE);
        }
        
        }catch(NumberFormatException e){
            JOptionPane.showMessageDialog(frame, "Inputan Tidak Valid !","Error",JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void update(String judullama){
        try {
        movie dm = new movie();
        dm.setJudul(frame.getJTextJudul().getText());
        dm.setJudulLama(judullama);
        dm.setAlur(Double.parseDouble(frame.getJTextAlur().getText()));
        alur= dm.getAlur();
        dm.setPenokohan(Double.parseDouble(frame.getJTextPenokohan().getText()));
        penokohan = dm.getPenokohan();
        dm.setAkting(Double.parseDouble(frame.getJTextAkting().getText()));
        akting = dm.getAkting();
        nilai = (alur+penokohan+akting)/3;
        dm.setNilai(nilai);
        if(0<alur && alur<=5 && 0<akting && akting<=5 && 0<penokohan && penokohan<=5){
        impmovie.update(dm);
        JOptionPane.showMessageDialog(frame,"Data Movie Berhasil Diupdate !","Success",JOptionPane.INFORMATION_MESSAGE);
        }
        else{
            JOptionPane.showMessageDialog(frame, "Mohon Masukan Input Yang Sesuai Dengan Range 0,1 - 5 !","Invalid",JOptionPane.ERROR_MESSAGE);
        }
        
        }catch(NumberFormatException e){
            JOptionPane.showMessageDialog(frame, "Inputan Tidak Valid !","Error",JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void delete(){
        String judul = frame.getJTextJudul().getText();
        impmovie.delete(judul);     
        JOptionPane.showMessageDialog(frame, "Penghapusan Data Movie Berhasil !","Delete Success",JOptionPane.WARNING_MESSAGE);
    }
    
    public void truncate(){
        int conf =JOptionPane.showOptionDialog(frame, "Yakin Ingin Mengapus Table ?","Hapus Table",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE,null,null,null);
        if(conf == JOptionPane.YES_OPTION){
            impmovie.truncate();
        }
    }
}
