/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

/**
 *
 * @author Irsyad
 */
public class Movie {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        UI view = new UI();
        view.setVisible(true);
        view.setLocationRelativeTo(null);
    }
    
}
